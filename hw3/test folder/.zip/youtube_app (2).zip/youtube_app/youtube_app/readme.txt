django-admin startproject назва проекту
python manage.py startapp yазва додатку
пробуй сама по черзі в консолназва додатку main
